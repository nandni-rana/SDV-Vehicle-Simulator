class SimpleAIDriver:
    def __init__(self, vehicle, speed_sensor, obstacle_sensor, logger, max_speed=50):
        self.vehicle = vehicle
        self.speed_sensor = speed_sensor
        self.obstacle_sensor = obstacle_sensor
        self.logger = logger
        self.max_speed = max_speed

    def monitor_and_control(self):
        speed = self.speed_sensor.read_speed()
        obstacle = self.obstacle_sensor.detect()

        if obstacle:
            decision = "Brake - Obstacle"
            print("⚠️ Obstacle detected! Applying emergency brake!")
            self.vehicle.brake(30)
        elif speed > self.max_speed:
            decision = "Brake - Overspeed"
            print("⚠️ Overspeed detected! Slowing down...")
            self.vehicle.brake(20)
        else:
            decision = "Continue Driving"
            print("✅ Safe. Continuing drive.")

        self.logger.log(speed, obstacle, decision)
