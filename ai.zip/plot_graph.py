import csv
import matplotlib.pyplot as plt
from datetime import datetime

timestamps = []
speeds = []
obstacles = []

# Read data from CSV
with open('vehicle_log.csv', 'r') as file:
    reader = csv.DictReader(file)
    for row in reader:
        timestamps.append(datetime.strptime(row['Timestamp'], '%Y-%m-%d %H:%M:%S'))
        speeds.append(int(row['Speed']))
        obstacles.append(row['Obstacle'] == 'True')  # Convert to boolean

# Plot speed line
plt.figure(figsize=(10, 5))
plt.plot(timestamps, speeds, marker='o', color='blue', label='Speed')

# Plot obstacle points in red
for i in range(len(obstacles)):
    if obstacles[i]:
        plt.scatter(timestamps[i], speeds[i], color='red', label='Obstacle' if i == 0 else "")

# Final touches
plt.title('Vehicle Speed Over Time with Obstacles')
plt.xlabel('Time')
plt.ylabel('Speed (km/h)')
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig("speed_obstacle_plot.png")  # Optional: Save graph
plt.show()
