import winsound

# 🔊 Play 1000 Hz beep for 500 ms
winsound.Beep(1000, 500)
