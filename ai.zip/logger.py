import csv
from datetime import datetime

class DataLogger:
    def __init__(self, filename="vehicle_log.csv"):
        self.filename = filename
        self.fields = ['Timestamp', 'Speed', 'Obstacle', 'Decision']
        # Create file with headers if not exists
        with open(self.filename, 'w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=self.fields)
            writer.writeheader()

    def log(self, speed, obstacle, decision):
        with open(self.filename, 'a', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=self.fields)
            writer.writerow({
                'Timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'Speed': speed,
                'Obstacle': obstacle,
                'Decision': decision
            })
