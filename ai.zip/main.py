import matplotlib.pyplot as plt
import csv

time_data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
speed = [80, 68, 71, 74, 77, 80, 83, 86, 89, 92]

def ai_decision(speed_value):
    if speed_value > 85:
        return "High Speed 🚨"
    elif speed_value < 65:
        return "Low Speed ⚠️"
    else:
        return "Normal ✅"

for i in range(len(speed)):
    decision = ai_decision(speed[i])
    print(f"Time: {time_data[i]} → Speed: {speed[i]} km/h → Decision: {decision}")

plt.plot(time_data, speed, marker='o', color='blue', label="Vehicle Speed")
plt.xlabel("Time")
plt.ylabel("Speed (km/h)")
plt.title("Vehicle Speed Monitoring with AI Decisions")
plt.grid(True)

for i in range(len(speed)):
    decision = ai_decision(speed[i])
    if "High" in decision or "Low" in decision:
        plt.annotate(decision, (time_data[i], speed[i]),
                     textcoords="offset points", xytext=(0,10),
                     ha='center', fontsize=8, color='red')

plt.legend()

plt.savefig("final_speed_graph.png")

plt.show()

with open('ai_speed_decisions.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['Time', 'Speed', 'Decision'])  # Header
    for i in range(len(speed)):
        decision = ai_decision(speed[i])
        writer.writerow([time_data[i], speed[i], decision])
