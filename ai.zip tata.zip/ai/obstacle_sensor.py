import random

class ObstacleSensor:
    def __init__(self):
        self.obstacle_present = False

    def detect(self):
        # Randomly simulate obstacle (True/False)
        self.obstacle_present = random.choice([True, False])
        if self.obstacle_present:
            print("🚧 Obstacle Detected Ahead!")
        else:
            print("✅ No Obstacle in Path.")
        return self.obstacle_present
