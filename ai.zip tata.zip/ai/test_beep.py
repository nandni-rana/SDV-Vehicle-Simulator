from vehicle import Vehicle
from obstacle_sensor import ObstacleSensor
from logger import DataLogger
from ai import SimpleAIDriver

import random
import time

# Dummy SpeedSensor class
class SpeedSensor:
    def __init__(self):
        self.speed = random.randint(30, 100)

    def read_speed(self):
        self.speed = random.randint(30, 100)
        print(f"🚗 Current Speed: {self.speed} km/h")
        return self.speed

# Bana lo objects
vehicle = Vehicle()
speed_sensor = SpeedSensor()
obstacle_sensor = ObstacleSensor()
logger = DataLogger()

# AI Driver
driver = SimpleAIDriver(vehicle, speed_sensor, obstacle_sensor, logger, max_speed=60)

# Test loop
for _ in range(5):
    driver.monitor_and_control()
    time.sleep(2)  # 2 second delay for realism
