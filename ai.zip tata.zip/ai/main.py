from vehicle import Vehicle
from obstacle_sensor import ObstacleSensor
from logger import DataLogger
from ai import SimpleAIDriver
from beep_player import play_beep

import random
import time
import csv
import matplotlib.pyplot as plt

# ----------------------------
# 1️⃣ Bana lo Sensors & Driver
# ----------------------------

# Dummy speed sensor
class SpeedSensor:
    def __init__(self):
        self.speed = random.randint(30, 100)

    def read_speed(self):
        self.speed = random.randint(30, 100)
        print(f"🚗 Current Speed: {self.speed} km/h")
        return self.speed

vehicle = Vehicle()
speed_sensor = SpeedSensor()
obstacle_sensor = ObstacleSensor()
logger = DataLogger()

driver = SimpleAIDriver(vehicle, speed_sensor, obstacle_sensor, logger, max_speed=60)

# ----------------------------
# 2️⃣ AI Driver Monitoring Loop
# ----------------------------

print("\n🚦 Starting AI Monitoring...\n")

for _ in range(5):  # 5 checks — tu jitne chahe loop kar le
    driver.monitor_and_control()
    time.sleep(2)  # 2 second delay

print("\n✅ Monitoring Done!\n")

# ----------------------------
# 3️⃣ Plot graph from log file
# ----------------------------

timestamps = []
speeds = []
obstacles = []

# Read vehicle_log.csv created by logger
with open('vehicle_log.csv', 'r') as file:
    reader = csv.DictReader(file)
    for row in reader:
        timestamps.append(row['Timestamp'])
        speeds.append(int(row['Speed']))
        obstacles.append(row['Obstacle'] == 'True')

plt.figure(figsize=(10, 5))
plt.plot(timestamps, speeds, marker='o', label="Speed (km/h)")

# Mark obstacles
for i in range(len(obstacles)):
    if obstacles[i]:
        plt.scatter(timestamps[i], speeds[i], color='red', label="Obstacle" if i == 0 else "")

plt.xlabel("Time")
plt.ylabel("Speed (km/h)")
plt.title("Vehicle Speed Monitoring with AI Decisions")
plt.xticks(rotation=45)
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig("final_speed_graph.png")
plt.show()
