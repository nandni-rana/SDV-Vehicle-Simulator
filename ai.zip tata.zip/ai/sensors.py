class SpeedSensor:
    def __init__(self, vehicle):
        self.vehicle = vehicle

    def read_speed(self):
        speed = self.vehicle.get_speed()
        print(f"Speed Sensor Reading: {speed} km/h")
        return speed
