# beep_player.py

import winsound

def play_beep():
    # frequency, duration
    winsound.Beep(1000, 500)  # 1000 Hz, 500 ms
