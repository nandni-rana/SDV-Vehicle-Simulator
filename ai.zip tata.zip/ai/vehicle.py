class Vehicle:
    def __init__(self, model="SDV-Prototype", speed=0):
        self.model = model
        self.speed = speed

    def accelerate(self, increase_by):
        self.speed += increase_by
        print(f"{self.model} accelerated to {self.speed} km/h.")

    def brake(self, decrease_by):
        self.speed = max(0, self.speed - decrease_by)
        print(f"{self.model} slowed down to {self.speed} km/h.")

    def get_speed(self):
        return self.speed
