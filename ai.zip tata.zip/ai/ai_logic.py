# ai_logic.py

class AIDecisionSystem:
    def __init__(self, speed_limit=80):
        self.speed_limit = speed_limit

    def evaluate_speed(self, speed):
        if speed > self.speed_limit:
            return "Overspeeding! Apply brakes."
        elif speed < 10:
            return "Too slow. Check vehicle status."
        else:
            return "Speed is within safe range."
